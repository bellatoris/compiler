int main(){
	int a;
	int b;

	int x;

	a = 1;
	b = 2;

	if (a == b) {
		x = 1;
	} else {
		x = 0;
	}

	write_int(x);
	write_string("\n");
}
