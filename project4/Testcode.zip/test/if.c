int main(){
	int a;
	int b;

	int x;

	if(a == b){
		x = 1;
	}else{
		x = 0;
	}
}
