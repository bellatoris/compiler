int main(){
	int a;

	++a;
}
