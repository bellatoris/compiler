int main(){
	int *a;
	int *b;

	a = &(*b++);

}

