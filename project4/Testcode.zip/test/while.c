int main(){
	int i;
	int j;

	i = 0;

	while(i < 10){
		i = i + 1;
		i++;
	}
}
